/**
 * Name: Angelina
 * Date: June 19, 2022
 * Course: ICS4UE   
 * Description: The following program was created as a final project in ISC4U, 
 *              it's a game of Go Fish which features player vs AI
 */


// Imports
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Main
{
  public static void main(String[] args)
  {
        // This boolean variable is true when game runs
        boolean gameRun = true;
        // Calls for scan variable
        Scanner scan = new Scanner(System.in);
        
        Random rand = new Random();
        
        while(gameRun)
        {
            // Calls deck
            Deck theDeck = new Deck();
            
            boolean playerTurn = true;
            boolean match = false;
            
            System.out.println();
            System.out.format("Welcome to Go Fish!\nThe player with the most matches at the end of the game wins.\nWhen a player runs out of cards, it's game over.\nPress 1 to begin. ");
            
            // Creates player and AI ID
            Player A = new Player();
            Player AI = new Player();
            
            // Creates hands for each player
            for(int i = 0; i < 7; i++)
            {
                A.addHand(theDeck);
                AI.addHand(theDeck);
            }
            
            // Creates ArrayList for each hand
            ArrayList<Card> handA = A.showHand();
            ArrayList<Card> handAI = AI.showHand();
            
            int enter = scan.nextInt();
            
            if(enter == 1)
            {
                while(handA.size() > 0)
                {
                    if(playerTurn == true)
                    {
                        System.out.println();
                        A.insertionSort();
                        A.ownMatch();
                        System.out.println("Player, here are your cards: " + handA);
                        System.out.println(handAI);
                        
                        System.out.println("Please enter the index of the card you wish to pair.");
                        System.out.println();
                        int index = scan.nextInt();
                        
                        while(index > handA.size() - 1)
                        {
                            System.out.println("That index isn't available. Try again.");
                            index = scan.nextInt();
                        }
                        
                        System.out.println("The card value is: " + handA.get(index).getValue());
                        
                        int value = handA.get(index).getValue();
                        
                        // Checks for a matching value in handAI ArrayList
                        int indexAI = 0;
                        for(int i = 0; i < handAI.size(); i++)
                        {
                            if(handAI.get(i).getValue() == value)
                            {
                                indexAI = i;
                                match = true;
                            }
                        }
                        
                        if(match == true)
                        {
                            System.out.println();
                            System.out.println("Match found!");
                            handAI.remove(indexAI);
                            handA.remove(index);
                            A.addPoint();
                            
                            // Makes sure AI has cards in hand
                            if(handAI.size() < 1)
                            {
                                AI.addHand(theDeck);
                            }
                            
                            playerTurn = false;
                        }
                        
                        if(match == false)
                        {
                            System.out.println("No match found, go fish.");
                            if(theDeck.deckSize() > 0)
                            {
                                A.addHand(theDeck);
                                A.ownMatch();
                            }
                            System.out.println("Here are your current cards: " + handA);
                            playerTurn = false;
                        }
                        match = false;
                        System.out.println("Your score: " + A.returnPoints());
                        System.out.println("AI score: " + AI.returnPoints());
                    }
                    
                    if(playerTurn == false)
                    {
                        AI.ownMatch();
                        // Generates a random index number for AI to call
                        int max = handAI.size() - 1;
                        int min = 0;
                        int randomIndex = rand.nextInt((max - min) + 1) + min;
                        
                        System.out.println();
                        
                        System.out.println("The computer has picked: " + handAI.get(randomIndex));
                        System.out.println();
                        
                        int value = handAI.get(randomIndex).getValue();
                        System.out.println("The value is: " + value);
                        
                        // Checks for a matching value in handA ArrayList
                        int indexA = 0;
                        for(int i = 0; i < handA.size(); i++)
                        {
                            if(handA.get(i).getValue() == value)
                            {
                                indexA = i;
                                match = true;
                            }
                        }

                        if(match == true)
                        {
                            System.out.println();
                            System.out.println("Match found!");
                            handAI.remove(randomIndex);
                            handA.remove(indexA);
                            AI.addPoint();
                            playerTurn = true;
                        }
                        if(match == false)
                        {
                            System.out.println("No match found, go fish.");
                            if(theDeck.deckSize() > 0)
                            {
                                AI.addHand(theDeck);
                                AI.ownMatch();
                            }
                            playerTurn = true;
                            System.out.println();
                        }
                        match = false;
                        System.out.println("Your score: " + A.returnPoints());
                        System.out.println("AI score: " + AI.returnPoints());
                    }
                    
                    /** The following code checks hand sizes, if there is an insufficient,
                     * amount, a player is declared winner.
                     */
                    
                    if(theDeck.deckSize() < 1)
                    {
                        if(handAI.size() < 1)
                        {
                            System.out.println();
                            System.out.println("There are no more cards to be used!");
                            System.out.println();
                            
                            if(A.points > AI.points)
                            {
                                System.out.println("You win!");
                                System.out.println("Your score: " + A.returnPoints());
                                System.out.println("Computer's score: " + AI.returnPoints());
                                gameRun = false;
                            }
                            
                            else if(A.points < AI.points)
                            {
                                System.out.println("Computer wins!");
                                System.out.println("Your score: " + A.returnPoints());
                                System.out.println("Player B's score: " + AI.returnPoints());
                                gameRun = false;
                            }
                            
                            else
                            {
                                System.out.println("It's a tie!");
                                System.out.println("Your score: " + A.returnPoints());
                                System.out.println("Computer's score: " + AI.returnPoints());
                                gameRun = false;
                            }
                        }
                        
                        if(handA.size() < 1)
                        {
                            System.out.println();
                            System.out.println("There are no more cards to be used!");
                            System.out.println();
                            
                            if(A.points > AI.points)
                            {
                                System.out.println("You win!");
                                System.out.println("Your score: " + A.returnPoints());
                                System.out.println("Computer's score: " + AI.returnPoints());
                                gameRun = false;
                            }
                            
                            else if(A.points < AI.points)
                            {
                                System.out.println("Computer wins!");
                                System.out.println("Your score: " + A.returnPoints());
                                System.out.println("Player B's score: " + AI.returnPoints());
                                gameRun = false;
                            }
                            
                            else
                            {
                                System.out.println("It's a tie!");
                                System.out.println("Your score: " + A.returnPoints());
                                System.out.println("Computer's score: " + AI.returnPoints());
                                gameRun = false;
                            }
                        }
                    }
                }
            }
        }
    
  }
}