import java.util.ArrayList;

public class Deck
{

    // Initializes ArrayList for the deck of cards. 
    private static ArrayList<Card> stack = new ArrayList<Card>();
    
    // Initializes card values and suits to be used in Deck()
    public int cardValue[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    public String cardSuit[] = {"S", "C", "H", "D"};
    
    public Deck()
    {
        // Creates cards with spade suit
        for(int i = 0; i < 9; i++)
        {
            stack.add(new Card(cardSuit[0], cardValue[i]));
        }
        
        // Creates cards with club suit
        for(int i = 0; i < 9; i++)
        {
            stack.add(new Card(cardSuit[1], cardValue[i]));
        }
        
        // Creates cards with heart suit
        for(int i = 0; i < 9; i++)
        {
            stack.add(new Card(cardSuit[2], cardValue[i]));
        }
        
        // Creates cards with diamond suit
        for(int i = 0; i < 9; i++)
        {
            stack.add(new Card(cardSuit[3], cardValue[i]));
        }
        
    }
    
    // This method returns the size of the deck
    public static int deckSize()
    {
        return stack.size();
    }
    
    /**
     * The following method generates a random number within the index
     * of available cards
     */
    public Card toHand()
    {
        int max = stack.indexOf(0);
        int min = deckSize(); 
        // Finds a random number between the max and min stated above.
        int randInt = (int)Math.floor(Math.random()*(max-min+1)+min);
        
        return stack.remove(randInt);
    }
}