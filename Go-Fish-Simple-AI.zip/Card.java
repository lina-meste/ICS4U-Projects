public class Card
{
    private int value;
    private String suit;
    
    /**
     * Creates Card object
     * @param suit: the type of card 
     * @param value: the number associated with the card 
     */ 
    public Card(String suit, int value)
    {
        this.suit = suit;
        this.value = value;
    }
    
    public String toString()
    {
        return "" + suit + value;
    }

    public int getValue()
    {
        return value;
    }
}