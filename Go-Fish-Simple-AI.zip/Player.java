import java.util.ArrayList;

public class Player
{
    // Variable for player points
    public int points = 0;
    
    // Initializing Arraylist for Player's hands
    private ArrayList<Card> hand = new ArrayList<Card>();
    
    public void addHand(Deck theDeck)
    {
        hand.add(theDeck.toHand());
    }
    
    // Method to add points to respective players total
    public void addPoint()
    {
        points++;
    }
    
    // Method to return total points
    public int returnPoints()
    {
        return points; 
    }
    
   public ArrayList<Card> showHand()
   {
       return hand;
   }
   
   // Method to sort through players deck so it is organized from least to greatest
   public void insertionSort()
   {
       for(int i = 1; i < hand.size(); i++)
       {
           Card sort = hand.get(i);
           int k = i;
           
           /**
            * Sorts through each index checking for an element that is of least 
            * value and then puts it in it's respective position
            * (least value starting at index 0)
            */
           while (k > 0 && hand.get(k-1).getValue() > sort.getValue())
           {
               hand.set(k, hand.get(k-1));
               k--;
           }
           hand.set(k, sort);
       }
   }
   
   public void ownMatch()
   {
       for(int i = 0; i < hand.size(); i++)
       {
           for(int j = 1; j < hand.size() - 1; j++)
           {
               
                if(hand.get(i).getValue() == hand.get(j).getValue())
                {
                    System.out.println("Match within hand found.");
                    System.out.println(hand.get(i) + " " + hand.get(j));
                    System.out.println();
                       
                       addPoint();
                    hand.remove(i);
                    hand.remove(j-1);
                }  
               
           }
       }
   }
}